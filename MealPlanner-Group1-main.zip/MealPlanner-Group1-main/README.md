setup the .venv and
install the following(e.g) pip install fastapi:
fastapi,
openai,
uvicorn,
langchain,
asyncio,
asyncpg,
python-dotenv,
Flask
google-generativeai, and 
python-dotenv

For the .env file
make a file name .env where the app.py
Put the following below and make sure to change Your Gemini API Key with your gemini api key:
GEMINI_API_KEY = Your Gemini API Key
